// Loader effect
$(window).on('load', function () {
    $('#status').fadeOut(2550);
    $('#loader').fadeOut(2750);
});